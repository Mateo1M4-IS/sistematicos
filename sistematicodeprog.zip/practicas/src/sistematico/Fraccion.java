package sistematico;


	import javax.swing.JOptionPane;

	
	public class Fraccion {
	    
		  public static int[] sumarFracciones(int num1, int den1, int num2, int den2) {
		        int mcm = mcm(den1, den2);
		        int numComun1 = num1 * (mcm / den1);
		        int numComun2 = num2 * (mcm / den2);
		        int numResultado = numComun1 + numComun2;
		        return simplificarFraccion(numResultado, mcm);
		    }

		    // Método para restar fracciones
		    public static int[] restarFracciones(int num1, int den1, int num2, int den2) {
		        int mcm = mcm(den1, den2);
		        int numComun1 = num1 * (mcm / den1);
		        int numComun2 = num2 * (mcm / den2);
		        int numResultado = numComun1 - numComun2;
		        return simplificarFraccion(numResultado, mcm);
		    }

		    // Método para multiplicar fracciones
		    public static int[] multiplicarFracciones(int num1, int den1, int num2, int den2) {
		        int numResultado = num1 * num2;
		        int denResultado = den1 * den2;
		        return simplificarFraccion(numResultado, denResultado);
		    }

		    // Método para dividir fracciones
		    public static int[] dividirFracciones(int num1, int den1, int num2, int den2) {
		        int numResultado = num1 * den2;
		        int denResultado = den1 * num2;
		        if (denResultado < 0) {
		            numResultado = -1 * numResultado;
		            denResultado = -1 * denResultado;
		        }
		        return simplificarFraccion(numResultado, denResultado);
		    }

		    // Método para comparar fracciones
		    public static int compararFracciones(int num1, int den1, int num2, int den2) {
		        int mcm = mcm(den1, den2);
		        int numComun1 = num1 * (mcm / den1);
		        int numComun2 = num2 * (mcm / den2);
		        if (numComun1 > numComun2) {
		            return 1;
		        } else if (numComun1 < numComun2) {
		            return -1;
		        } else {
		            return 0;
		        }
		    }

		    // Método para simplificar una fracción
		    public static int[] simplificarFraccion(int numerador, int denominador) {
		        int mcd = mcd(numerador, denominador);
		        int numFinal = numerador / mcd;
		        int denFinal = denominador / mcd;
		        return new int[] { numFinal, denFinal };
		    }

		    // Método para encontrar el MCM de dos números
		    public static int mcm(int a, int b) {
		        return (a * b) / mcd(a, b);
		    }

		    // Método para encontrar el MCD de dos números
		    public static int mcd(int a, int b) {
		        if (b == 0) {
		            return a;
		        } else {
		            return mcd(b, a % b);
		        }
		    }
	}
	    
	    
	

