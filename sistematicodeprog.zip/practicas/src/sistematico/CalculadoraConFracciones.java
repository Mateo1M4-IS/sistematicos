package sistematico;

import java.util.Scanner;


public class CalculadoraConFracciones extends Fraccion {
    public static void main(String[] args) {
    	Scanner tc=new Scanner(System.in);
	try {
    	System.out.println("ingrese la primera fraccion");
		int numerador1=tc.nextInt(); ;
	        int denominador1 =tc.nextInt();
	        System.out.println("ingrese segunda fraccion ");
	        int numerador2 = tc.nextInt();
	        int denominador2 =  tc.nextInt();
int op=0;
    	
    /*	// Sumar fracciones
        int[] suma = sumarFracciones(numerador1, denominador1, numerador2, denominador2);
        System.out.println("Suma: " + suma[0] + "/" + suma[1]);

        // Restar fracciones
        int[] resta = restarFracciones(numerador1, denominador1, numerador2, denominador2);
        System.out.println("Resta: " + resta[0] + "/" + resta[1]);

        // Multiplicar fracciones
        int[] multiplicacion = multiplicarFracciones(numerador1, denominador1, numerador2, denominador2);
        System.out.println("Multiplicación: " + multiplicacion[0] + "/" + multiplicacion[1]);

        // Dividir fracciones
        int[] division = dividirFracciones(numerador1, denominador1, numerador2, denominador2);
        System.out.println("División: " + division[0] + "/" + division[1]);

        // Comparar fracciones
        int comparacion = compararFracciones(numerador1, denominador1, numerador2, denominador2);
        if (comparacion == 1) {
            System.out.println("Fracción 1 es mayor");
        } else if (comparacion == -1) {
            System.out.println("Fracción 2 es mayor");
        } else {
            System.out.println("Las fracciones son iguales");
        }*/
    
System.out.println("ingrese una opcion ");
System.out.println("la opcion 1 suma \nla opcion 2 resta \n la opcion 3 multiplica \n la opcion 4 divide \n la opcion 5 compara las fracciones \n la opcion 6 es para salir ");
op=tc.nextInt();
switch(op) {
case 1:
	  int[] suma = sumarFracciones(numerador1, denominador1, numerador2, denominador2);
      System.out.println("Suma: " + suma[0] + "/" + suma[1]);
break;
case 2:
	 int[] resta = restarFracciones(numerador1, denominador1, numerador2, denominador2);
     System.out.println("Resta: " + resta[0] + "/" + resta[1]);
	break;
case 3: 
	  int[] multiplicacion = multiplicarFracciones(numerador1, denominador1, numerador2, denominador2);
      System.out.println("Multiplicación: " + multiplicacion[0] + "/" + multiplicacion[1]);
break;
case 4:
	 int[] division = dividirFracciones(numerador1, denominador1, numerador2, denominador2);
     System.out.println("División: " + division[0] + "/" + division[1]);
break;
case 5:
	int comparacion = compararFracciones(numerador1, denominador1, numerador2, denominador2);
    if (comparacion == 1) {
        System.out.println("Fracción 1 es mayor");
    } else if (comparacion == -1) {
        System.out.println("Fracción 2 es mayor");
    } else {
        System.out.println("Las fracciones son iguales");
  break;
    }
case 6:
	  System.out.println("adios...");
  
    }
  
	}catch(Exception e ) {
		System.out.println("Dato invalido ");
	}



}
}


		


	


