package segundo;
import java.util.Scanner;
public class persona {
	Scanner tc= new Scanner(System.in);
	private int  dni=2023;
	private String nombre="mateo";
	private int edad;

	
	public persona() {
		super();
		this.tc = tc;
		this.dni = dni;
		this.nombre = nombre;
		this.edad = edad;
	}
	
	public Scanner getTc() {
		return tc;
	}

	public void setTc(Scanner tc) {
		this.tc = tc;
	}

	public int getDni() {
		return dni;
	}

	public void setDni(int dni) {
		this.dni = dni;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public int getEdad() {
		return edad;
	}

	public void setEdad(int edad) {
		this.edad = edad;
	}
public void motrar() {
	
}
	
	public void edad() {
try {
		System.out.println("ingrese edad ");
		edad=tc.nextInt();
		if(edad <= 18) {
			System.out.println(""+nombre + " es menor de edad y no tiene DNI su edad es de: "+edad);
			
		}else {
			System.out.println("el nombre es "+nombre +"\n "+"Y la edad es"+ +edad +"\n"+ "El dni : "+dni);
		}
}catch(Exception e) {
	System.out.println("dato invalido ");
}
		
	}
	
}
