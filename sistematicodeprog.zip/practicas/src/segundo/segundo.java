package segundo;

public class segundo {

	public static void main(String[] args) {
	persona op=new persona();

	op.motrar();
	op.edad();
	
	
	}

}
