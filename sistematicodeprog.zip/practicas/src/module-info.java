/**
 * 
 */
/**
 * @author Luis
 *
 */
module practicas {
	requires java.desktop;
}