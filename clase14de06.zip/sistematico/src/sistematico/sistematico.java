package sistematico;
import java.util.ArrayList;
import java.util.Scanner;
public class sistematico {


		
		
			public static void main(String[] args) {
int suma=0;
double media;
	int con=1;
			ArrayList al = new ArrayList();
		
		int num=0;
	    ArrayList<Integer> numeros = new ArrayList<Integer>();
	   try {
	    Scanner tc = new Scanner(System.in); 
	    
	  
	  
	      while(num!=99) {
	    	  
	        System.out.println("ingrese un numero");
	    
	        num = tc.nextInt();
	   
	        if(num==-99) {
		    	 break;
	        }
	       suma+=num;
	       
	       numeros.add(num);
	       con++;
	        }
	     
	        
	     
	    media=suma/con;
	
	    for(Integer i: numeros){
	      System.out.println("valores "+i);
		
			}
		System.out.println("la suma es "+suma);
			System.out.println("la media es "+media);
			

			}catch(Exception e) {
				System.out.println("dato no valido ");
			}
			}
			
			
		
	}
